document.addEventListener('DOMContentLoaded', function () {
  let currentEditId = null;
  const listPage = document.getElementById('listPage');
  const formPage = document.getElementById('formPage');

  // 页面切换函数
  function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
  }

  // 重置表单
  function resetForm() {
    document.getElementById('siteName').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('usernameSelector').value = '';
    document.getElementById('passwordSelector').value = '';
    document.getElementById('submitSelector').value = '';
    currentEditId = null;
  }

  // 渲染列表
  // 添加辅助函数（在文件开头，DOMContentLoaded 事件监听器内的顶部）
  function tryAutoLogin(tabId, siteId, isRetry = false) {
    chrome.tabs.sendMessage(tabId, {
      action: 'autoLogin',
      siteId: siteId
    }, function (response) {
      if (!response && !isRetry) {
        // 如果是首次尝试失败，刷新页面后重试
        chrome.tabs.reload(tabId, {}, function () {
          // 等待页面加载完成后再次尝试登录
          setTimeout(() => {
            tryAutoLogin(tabId, siteId, true);
          }, 1000);
        });
      } else if (!response && isRetry) {
        alert('登录失败：页面无响应，请检查页面是否正常加载');
      } else if (response.success) {
        window.close();
      } else {
        alert('自动登录失败：\n' + (response.error || '未知错误'));
      }
    });
  }

  // 修改渲染列表函数中的快速登录按钮处理部分
  function renderList() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentUrl = tabs[0].url;
      const normalizeUrl = (url) => {
        return url.replace(/^https?:\/\//, '')
          .replace(/\/$/, '')
          .replace(/\?.*$/, '');
      };
      const currentNormalizedUrl = normalizeUrl(currentUrl);

      chrome.storage.local.get(null, function (items) {
        const listContainer = document.getElementById('loginList');
        listContainer.innerHTML = '';

        let matchedSite = null;

        // 渲染列表项
        Object.keys(items).forEach(key => {
          if (key.startsWith('site_')) {
            const site = items[key];
            const listItem = document.createElement('div');
            // 判断是否匹配当前URL，添加active类
            const isMatched = normalizeUrl(site.url) === currentNormalizedUrl;
            listItem.className = `list-item ${isMatched ? 'active' : ''}`;
            listItem.innerHTML = `
              <div class="site-info">
                <div class="site-name">${site.siteName}</div>
                <div class="site-url">${site.url}</div>
              </div>
              <div class="actions">
                <button class="btn-delete" data-id="${key}">
                  <i class="mdi mdi-delete"></i> 删除
                </button>
                <button class="btn-edit" data-id="${key}">
                  <i class="mdi mdi-pencil"></i> 编辑
                </button>
                <button class="btn-login" data-id="${key}">
                  <i class="mdi mdi-login"></i> 登录
                </button>
              </div>
            `;
            listContainer.appendChild(listItem);

            if (isMatched) {
              matchedSite = { ...site, id: key };
            }
          }
        });

        // 添加底部提示
        const bottomTip = document.createElement('div');
        bottomTip.className = 'bottom-tip';

        if (matchedSite) {
          bottomTip.innerHTML = `
            <div class="tip-content">
              <span>当前网址已存在配置，点击按钮进行登录</span>
              <button class="btn-quick-login" data-id="${matchedSite.id}">
                <i class="mdi mdi-login"></i> 点击登录
              </button>
            </div>
          `;
        }
        listContainer.appendChild(bottomTip);

        // 为快速登录按钮添加事件监听
        const quickLoginBtn = bottomTip.querySelector('.btn-quick-login');
        if (quickLoginBtn) {
          quickLoginBtn.addEventListener('click', function () {
            const siteId = this.dataset.id;
            tryAutoLogin(tabs[0].id, siteId);
          });
        }
      });
    });
  }

  // 新增按钮点击事件
  document.getElementById('addNew').addEventListener('click', function () {
    resetForm();
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentUrl = tabs[0].url;
      showPage('formPage');
    });
  });

  // 返回按钮点击事件
  document.getElementById('backToList').addEventListener('click', function () {
    showPage('listPage');
    renderList();
  });

  // 保存配置
  document.getElementById('save').addEventListener('click', function () {
    const siteData = {
      siteName: document.getElementById('siteName').value,
      username: document.getElementById('username').value,
      password: document.getElementById('password').value,
      usernameSelector: document.getElementById('usernameSelector').value,
      passwordSelector: document.getElementById('passwordSelector').value,
      submitSelector: document.getElementById('submitSelector').value
    };

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      siteData.url = tabs[0].url;
      const siteId = currentEditId || `site_${Date.now()}`;

      chrome.storage.local.set({ [siteId]: siteData }, function () {
        showPage('listPage');
        renderList();
      });
    });
  });

  // 修改列表操作事件委托
  document.getElementById('loginList').addEventListener('click', function (e) {
    const target = e.target;
    const siteId = target.dataset.id;

    if (target.classList.contains('btn-edit')) {
      chrome.storage.local.get(siteId, function (data) {
        const site = data[siteId];
        document.getElementById('siteName').value = site.siteName;
        document.getElementById('username').value = site.username;
        document.getElementById('password').value = site.password;
        document.getElementById('usernameSelector').value = site.usernameSelector || '#username';
        document.getElementById('passwordSelector').value = site.passwordSelector || '#password';
        document.getElementById('submitSelector').value = site.submitSelector || '.ant-btn';
        currentEditId = siteId;
        showPage('formPage');
      });
    } else if (target.classList.contains('btn-login')) {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const currentUrl = tabs[0].url;
        chrome.storage.local.get(siteId, function (data) {
          const site = data[siteId];
          const normalizeUrl = (url) => {
            return url.replace(/^https?:\/\//, '')
              .replace(/\/$/, '')
              .replace(/\?.*$/, '');
          };
          const currentNormalizedUrl = normalizeUrl(currentUrl);
          const siteNormalizedUrl = normalizeUrl(site.url);

          if (currentNormalizedUrl === siteNormalizedUrl) {
            tryAutoLogin(tabs[0].id, siteId);
          } else {
            alert('当前网址与配置的网址不匹配，请检查！\n当前网址：' + currentUrl + '\n配置网址：' + site.url);
          }
        });
      });
    } else if (target.classList.contains('btn-delete')) {
      if (confirm('确定要删除这条配置吗？')) {
        chrome.storage.local.remove(siteId, function () {
          renderList();
        });
      }
    }
  });

  // 添加导出功能
  document.getElementById('exportData').addEventListener('click', function () {
    chrome.storage.local.get(null, function (items) {
      const exportData = {};
      Object.keys(items).forEach(key => {
        if (key.startsWith('site_')) {
          exportData[key] = items[key];
        }
      });

      if (Object.keys(exportData).length === 0) {
        alert('没有可导出的数据！');
        return;
      }

      const dataStr = JSON.stringify(exportData, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `auto-login-config-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  });

  // 修改导入按钮点击事件，改为显示导入页面
  document.getElementById('importData').addEventListener('click', function () {
    showPage('importPage');
  });

  // 添加返回按钮事件
  document.getElementById('backFromImport').addEventListener('click', function () {
    document.getElementById('importContent').value = '';
    showPage('listPage');
  });

  // 添加确认导入按钮事件
  document.getElementById('confirmImport').addEventListener('click', function () {
    const content = document.getElementById('importContent').value.trim();
    if (!content) {
      alert('请先粘贴要导入的数据');
      return;
    }

    try {
      const importData = JSON.parse(content);

      // 验证导入数据格式
      const isValidData = Object.entries(importData).every(([key, item]) => {
        return key.startsWith('site_') &&
          item &&
          typeof item === 'object' &&
          'siteName' in item &&
          'url' in item &&
          'username' in item &&
          'password' in item &&
          'usernameSelector' in item &&
          'passwordSelector' in item &&
          'submitSelector' in item;
      });

      if (!isValidData) {
        throw new Error('导入失败：数据格式不正确，请确保是从本插件导出的配置文件');
      }

      // 保存导入的数据
      chrome.storage.local.set(importData, function () {
        if (chrome.runtime.lastError) {
          alert('保存失败：' + chrome.runtime.lastError.message);
        } else {
          alert('数据导入成功！共导入 ' + Object.keys(importData).length + ' 条配置');
          document.getElementById('importContent').value = '';
          showPage('listPage');
          renderList();
        }
      });
    } catch (error) {
      if (error instanceof SyntaxError) {
        alert('导入失败：JSON 格式不正确，请确保粘贴的内容是有效的 JSON 格式');
      } else {
        alert(error.message);
      }
    }
  });

  // 修改重置表单函数，添加默认值
  function resetForm() {
    document.getElementById('siteName').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('usernameSelector').value = '#username';
    document.getElementById('passwordSelector').value = '#password';
    document.getElementById('submitSelector').value = '.ant-btn';
    currentEditId = null;
  }

  // 初始化显示列表
  renderList();
});