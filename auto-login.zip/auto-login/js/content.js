// 通知插件页面已准备就绪
chrome.runtime.sendMessage({ action: 'contentScriptReady' });

// 监听来自插件的消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === 'autoLogin') {
    // 确保页面完全加载
    if (document.readyState === 'complete') {
      handleAutoLogin(request, sendResponse);
    } else {
      window.addEventListener('load', function () {
        handleAutoLogin(request, sendResponse);
      });
    }
    return true; // 保持消息通道开启
  }
});

function handleAutoLogin(request, sendResponse) {
  try {
    chrome.storage.local.get(request.siteId, function (data) {
      const site = data[request.siteId];

      // 检查配置数据是否完整
      if (!site) {
        throw new Error('未找到登录配置数据');
      }

      // 查找所需元素并记录状态
      const elements = {
        username: {
          selector: site.usernameSelector,
          element: document.querySelector(site.usernameSelector),
          name: '用户名输入框'
        },
        password: {
          selector: site.passwordSelector,
          element: document.querySelector(site.passwordSelector),
          name: '密码输入框'
        },
        submit: {
          selector: site.submitSelector,
          element: document.querySelector(site.submitSelector),
          name: '登录按钮'
        }
      };

      // 检查是否所有元素都找到
      const missingElements = Object.entries(elements)
        .filter(([_, info]) => !info.element)
        .map(([_, info]) => `${info.name}(${info.selector})`);

      if (missingElements.length > 0) {
        throw new Error(`页面中未找到以下元素：\n${missingElements.join('\n')}`);
      }

      // 执行登录操作
      elements.username.element.value = site.username;
      elements.username.element.dispatchEvent(new Event('input', { bubbles: true }));

      elements.password.element.value = site.password;
      elements.password.element.dispatchEvent(new Event('input', { bubbles: true }));

      // 直接点击登录按钮
      setTimeout(() => {
        elements.submit.element.click();
        sendResponse({ success: true });
      }, 100);

    });
  } catch (error) {
    sendResponse({
      success: false,
      error: error.message || '自动登录过程中发生未知错误'
    });
  }
}

// 修改自动登录函数
function autoLogin(siteId) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(siteId, function (data) {
      const site = data[siteId];
      if (!site) {
        reject('未找到配置信息');
        return;
      }

      try {
        const usernameInput = document.querySelector(site.usernameSelector);
        const passwordInput = document.querySelector(site.passwordSelector);
        const submitButton = document.querySelector(site.submitSelector);

        if (!usernameInput || !passwordInput || !submitButton) {
          reject('未找到登录表单元素，请检查选择器配置');
          return;
        }

        // 填充用户名和密码
        usernameInput.value = site.username;
        passwordInput.value = site.password;

        // 触发 input 事件
        usernameInput.dispatchEvent(new Event('input', { bubbles: true }));
        passwordInput.dispatchEvent(new Event('input', { bubbles: true }));

        // 查找并点击复选框
        const checkbox = document.querySelector('input[type="checkbox"]');
        if (checkbox) {
          checkbox.click();
        }

        // 延迟一下再点击登录按钮，确保复选框点击事件已完成
        setTimeout(() => {
          submitButton.click();
          resolve({ success: true });
        }, 100);
      } catch (error) {
        reject('自动登录失败：' + error.message);
      }
    });
  });
}